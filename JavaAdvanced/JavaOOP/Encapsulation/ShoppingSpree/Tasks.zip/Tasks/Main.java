package Tasks;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] inputPerson = scanner.nextLine().split(";");

        Map<String, Person> mapPeople = new LinkedHashMap<>();
        Map<String, Product> mapProducts = new LinkedHashMap<>();

        for (String person : inputPerson) {
            String[] personParts = person.split("=");
            String namePerson = personParts[0];
            double moneyPerson = Double.parseDouble(personParts[1]);

            try {
                Person people = new Person(namePerson, moneyPerson);
                mapPeople.put(namePerson, people);
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                return;
            }
        }

        String[] inputProduct = scanner.nextLine().split(";");

        for (String product : inputProduct) {
            String[] productsParts = product.split("=");
            String nameProduct = productsParts[0];
            double costProduct = Double.parseDouble(productsParts[1]);

            try {
                Product products = new Product(nameProduct, costProduct);
                mapProducts.put(nameProduct, products);
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                return;
            }
        }

        String command = scanner.nextLine();

        while (!command.equals("END")) {
            String[] newCommand = command.split("\\s+");
            String namePerson = newCommand[0];
            String nameProduct = newCommand[1];

            try {
                Person person = mapPeople.get(namePerson);
                Product product = mapProducts.get(nameProduct);
                person.buyProduct(product);
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }

            command = scanner.nextLine();
        }

        for (Person person : mapPeople.values()) {
            System.out.print(person.getName() + " - ");
            if (person.getProducts().isEmpty()) {
                System.out.println("Nothing bought");
            } else {
                System.out.println(person.getProducts().stream().map(Product::getName).collect(Collectors.joining(", ")));
            }
        }
    }
}
