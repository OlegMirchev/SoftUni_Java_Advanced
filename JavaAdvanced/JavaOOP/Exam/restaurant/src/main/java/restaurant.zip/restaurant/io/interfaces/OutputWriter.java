package restaurant.src.main.java.restaurant.io.interfaces;

public interface OutputWriter {
    void writeLine(String text);
}
