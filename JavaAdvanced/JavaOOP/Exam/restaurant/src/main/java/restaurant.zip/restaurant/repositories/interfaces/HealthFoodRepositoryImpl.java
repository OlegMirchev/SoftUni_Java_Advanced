package restaurant.src.main.java.restaurant.repositories.interfaces;

import java.util.Collection;

public class HealthFoodRepositoryImpl implements HealthFoodRepository {
    @Override
    public Object foodByName(String name) {
        return null;
    }

    @Override
    public Collection getAllEntities() {
        return null;
    }

    @Override
    public void add(Object entity) {

    }
}
