package restaurant.src.main.java.restaurant.core.interfaces;

public interface Engine {
    void run();
}
