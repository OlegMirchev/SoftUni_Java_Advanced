package restaurant.src.main.java.restaurant.repositories.interfaces;

import restaurant.src.main.java.restaurant.entities.tables.interfaces.Table;

import java.util.Collection;
import java.util.List;

public class TableRepositoryImpl implements TableRepository {
    private List<TableRepositoryImpl> entities;

    @Override
    public Object byNumber(int number) {
        return null;
    }

    @Override
    public Collection getAllEntities() {
        return null;
    }

    @Override
    public void add(Object entity) {

    }
}
