package restaurant.src.main.java.restaurant;


import restaurant.src.main.java.restaurant.entities.drinks.interfaces.Beverages;
import restaurant.src.main.java.restaurant.entities.healthyFoods.interfaces.HealthyFood;
import restaurant.src.main.java.restaurant.entities.tables.interfaces.Table;
import restaurant.src.main.java.restaurant.repositories.interfaces.BeverageRepository;
import restaurant.src.main.java.restaurant.repositories.interfaces.HealthFoodRepository;
import restaurant.src.main.java.restaurant.repositories.interfaces.TableRepository;

public class Main {
    public static void main(String[] args) {
        // TODO: Optional - Create new instances for all repositories to test your code locally.

        HealthFoodRepository<HealthyFood> healthFoodRepository;
        BeverageRepository<Beverages> beverageRepository;
        TableRepository<Table> tableRepository;

        /*
        Controller controller = new ControllerImpl(healthFoodRepository, beverageRepository, tableRepository);

        ConsoleReader reader = new ConsoleReader();
        ConsoleWriter writer = new ConsoleWriter();
        EngineImpl engine = new EngineImpl(reader, writer, controller);
        engine.run();
        */
    }
}
