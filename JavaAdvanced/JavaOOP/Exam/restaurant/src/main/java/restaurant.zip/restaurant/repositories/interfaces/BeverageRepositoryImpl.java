package restaurant.src.main.java.restaurant.repositories.interfaces;

import java.util.Collection;

public class BeverageRepositoryImpl implements BeverageRepository {
    @Override
    public Object beverageByName(String drinkName, String drinkBrand) {
        return null;
    }

    @Override
    public Collection getAllEntities() {
        return null;
    }

    @Override
    public void add(Object entity) {

    }
}
