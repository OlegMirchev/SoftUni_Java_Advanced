package restaurant.src.main.java.restaurant.common.enums;

public enum HealthyFoodType {
    Salad,
    VeganBiscuits
}
