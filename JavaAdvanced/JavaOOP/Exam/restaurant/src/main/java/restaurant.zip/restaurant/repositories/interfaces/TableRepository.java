package restaurant.src.main.java.restaurant.repositories.interfaces;

public interface TableRepository<T> extends Repository<T> {

    T byNumber(int number);
}
