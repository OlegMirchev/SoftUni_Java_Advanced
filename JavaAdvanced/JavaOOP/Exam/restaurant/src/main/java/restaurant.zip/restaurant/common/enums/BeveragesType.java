package restaurant.src.main.java.restaurant.common.enums;

public enum BeveragesType {
    Smoothie,
    Fresh
}
