package restaurant.src.main.java.restaurant.common.enums;

public enum TableType {
    Indoors,
    InGarden
}
