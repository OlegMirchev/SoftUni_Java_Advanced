package ViceCity.src.main.java.viceCity.common;

public enum  Command {
    AddPlayer,
    AddGun,
    AddGunToPlayer,
    Fight,
    Exit,
}
