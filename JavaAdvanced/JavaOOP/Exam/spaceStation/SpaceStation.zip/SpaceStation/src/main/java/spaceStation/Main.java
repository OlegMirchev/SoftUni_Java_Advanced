package SpaceStation.src.main.java.spaceStation;

import SpaceStation.src.main.java.spaceStation.core.Controller;
import SpaceStation.src.main.java.spaceStation.core.ControllerImpl;
import SpaceStation.src.main.java.spaceStation.core.Engine;
import SpaceStation.src.main.java.spaceStation.core.EngineImpl;

public class Main {
    public static void main(String[] args) {
        Controller controller = new ControllerImpl();
        Engine engine = new EngineImpl(controller);

        engine.run();
    }
}
