package SpaceStation.src.main.java.spaceStation.core;

public interface Engine extends Runnable {
}
