package SpaceStation.src.main.java.spaceStation.models.astronauts;

import SpaceStation.src.main.java.spaceStation.models.bags.Bag;

public interface Astronaut {
    String getName();

    double getOxygen();

    boolean canBreath();

    Bag getBag();

    void breath();
}
