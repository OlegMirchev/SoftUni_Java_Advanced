package SpaceStation.src.main.java.spaceStation.common;

public enum Command {
    AddAstronaut,
    AddPlanet,
    RetireAstronaut,
    ExplorePlanet,
    Report,
    Exit,
}
