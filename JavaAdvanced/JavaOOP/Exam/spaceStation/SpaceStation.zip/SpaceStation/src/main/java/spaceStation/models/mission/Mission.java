package SpaceStation.src.main.java.spaceStation.models.mission;

import SpaceStation.src.main.java.spaceStation.models.astronauts.Astronaut;
import SpaceStation.src.main.java.spaceStation.models.planets.Planet;

import java.util.Collection;
import java.util.List;

public interface Mission {
    void explore(Planet planet, List<Astronaut> astronauts);
}
