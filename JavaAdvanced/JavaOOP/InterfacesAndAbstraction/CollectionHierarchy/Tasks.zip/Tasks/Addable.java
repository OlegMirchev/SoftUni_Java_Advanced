package Tasks;

public interface Addable {

    int add(String item);
}
