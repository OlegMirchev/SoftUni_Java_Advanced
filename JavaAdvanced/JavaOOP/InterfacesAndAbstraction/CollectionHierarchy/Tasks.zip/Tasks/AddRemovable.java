package Tasks;

public interface AddRemovable extends Addable {

    String remove();
}
