package Tasks;

import java.io.Serializable;

public interface Car extends Serializable {

    String brakes();
    String gas();
}
